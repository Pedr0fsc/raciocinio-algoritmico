# Imprima os números de 1 até 99, com incremento de 2. Exemplo: 1, 3, 5.....97, 99

for x in range(1, 100, 2):
    print(x)