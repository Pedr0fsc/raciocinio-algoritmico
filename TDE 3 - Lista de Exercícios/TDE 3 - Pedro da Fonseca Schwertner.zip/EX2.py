# Imprima os números de 50 até 0 com decremento de 5. Exemplo: 50, 45, 40.....5, 0

for x in range(50, -1, -5):
    print(x)