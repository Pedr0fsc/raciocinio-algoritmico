# Imprima os números de -100 até 100, com incremento de 10. Exemplo: -100, -90, -80.....90, 100

for x in range(-100, 101, 10):
    print(x)