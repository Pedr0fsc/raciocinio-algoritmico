# Imprima os números múltiplos de 4 existentes no intervalo aberto de 1 a 100.

for x in range(0, 101, 4):
    print(x)