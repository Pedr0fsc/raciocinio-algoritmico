# Imprima os números ímpares de 1 até n, sendo n fornecido pelo usuário.

n = int(input("Insira um número limite: "))

for x in range(1, n, 2):
    print(x)